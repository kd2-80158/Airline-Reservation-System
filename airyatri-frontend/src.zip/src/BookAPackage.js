function BookAPackage() {
    return ( <h1>Book a package</h1> );
}

export default BookAPackage;
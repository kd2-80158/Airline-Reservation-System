package com.app.entities;

public enum Class {
  ECONOMY, BUSINESS, VIP
}

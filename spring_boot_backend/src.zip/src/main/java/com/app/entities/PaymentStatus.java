package com.app.entities;

public enum PaymentStatus {
	
	NA, COMPLETED

}

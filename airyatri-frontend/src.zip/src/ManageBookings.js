function ManageBookings() {
    return ( <h1>Manage Bookings</h1> );
}

export default ManageBookings;
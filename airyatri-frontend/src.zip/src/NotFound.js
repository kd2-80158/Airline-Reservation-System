function NotFound() {
    return ( 
        <h1>Sorry!!The requested page doesn't exist</h1>
     );
}

export default NotFound;
function WhereWeFly() {
    return ( <h1>Where we Fly!</h1> );
}

export default WhereWeFly;
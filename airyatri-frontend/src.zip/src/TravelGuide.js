import '../node_modules/bootstrap/dist/css/bootstrap.min.css'

function TravelGuide() {
    return ( <div className='container'>
                <div className='table-responsive'>
                    <table className='table table-bordered'>
                        <thead>
                            <tr>
                                <th>Cabin or Carry-On-Baggage</th>
                                <th>Restricted Items</th>
                                <th>Excess Baggage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                                    Molestie at elementum eu facilisis sed odio morbi quis. Feugiat pretium nibh ipsum consequat nisl. 
                                    Auctor augue mauris augue neque gravida in fermentum et. Sed arcu non odio euismod lacinia at quis risus sed. 
                                    Morbi tincidunt ornare massa eget egestas purus viverra.</td>
                                    
                                <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                                    Molestie at elementum eu facilisis sed odio morbi quis. Feugiat pretium nibh ipsum consequat nisl. 
                                    Auctor augue mauris augue neque gravida in fermentum et. Sed arcu non odio euismod lacinia at quis risus sed. 
                                    Morbi tincidunt ornare massa eget egestas purus viverra. </td>
                                
                                <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                                    Molestie at elementum eu facilisis sed odio morbi quis. Feugiat pretium nibh ipsum consequat nisl. 
                                    Auctor augue mauris augue neque gravida in fermentum et. Sed arcu non odio euismod lacinia at quis risus sed. 
                                    Morbi tincidunt ornare massa eget egestas purus viverra.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div> );
}

export default TravelGuide;
package com.app.service;

public interface ResetPasswordService {

	boolean resetPassword(String email,String newPassword);
	

}

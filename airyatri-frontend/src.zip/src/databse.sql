
use airyatri;

select * from user;

select * from reservation;

select * from payment;



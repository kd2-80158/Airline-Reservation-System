package com.app.entities;

public enum PaymentMethod {
	
	VISA, MASTERCARD, PHONEPE, PAYTM, GOOGLEPAY

}
